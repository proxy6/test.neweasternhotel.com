module.exports = {
    apps: [{
        name: 'KingDunamis App',
        script: './server.js',
    }]
};